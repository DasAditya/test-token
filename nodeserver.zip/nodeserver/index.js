
import { createRequire } from 'module';
import * as fs from 'fs';

const perfPrivateKey = fs.readFileSync("./perf-privatekey.pem", "ascii");
const testPrivateKey = fs.readFileSync("./test-privatekey.pem", "ascii");
const require = createRequire(import.meta.url);
var StringBuffer = require("stringbuffer");
var HTTPRequest = require("request");

//Hapi framework
const Hapi = require('hapi');
const crypto = require('crypto');
//Address and port
const host = '127.0.0.1';
const port = 3000;

//Create server
const server = Hapi.Server({
  host: host,
  port: port
});

export function returnToken(key, clientID, usrname, audi, time){
  var token = new StringBuffer();
  var header = {"alg":"RS256"};
  token.append(Buffer.from(JSON.stringify(header)).toString('base64url'));
  token.append(".");

  var str = {"iss": clientID,
    "sub": usrname,
    "aud": "https://"+audi,
    "exp": parseInt(Date.now()/1000) + time,
    "jti": crypto.randomUUID()};

  token.append(Buffer.from(JSON.stringify(str)).toString('base64url'));


  const sign = crypto.createSign('RSA-SHA256');
  sign.update(Buffer.from(token.toString()));
  const signature = sign.sign(key);
  token.append(".");
  token.append(Buffer.from(signature).toString('base64url'));

  return token.toString()
}
// export function makeOAuthCall(audi, jwtToken){
//   var options = {
//     'method': 'POST',
//     'url': 'https://'+audi+'/services/oauth2/token',
//     'headers': {
//       'Content-Type': 'application/x-www-form-urlencoded',
//     },
//     form: {
//       'grant_type': 'urn:ietf:params:oauth:grant-type:jwt-bearer',
//       'assertion': jwtToken
//     }
//   };
//   HTTPRequest(options, function (error, response) {
//     if (error) return error;
//     if (!error) {
//       var responseBody = JSON.parse(response.body)
//       return responseBody
//     }
//   });
// }

//Start server
const init = async () => {
  await server.start();
  console.log("Server up! Port: " + port);
}

server.route({
  method: 'GET',
  path: '/getPerfToken/{clientID}+{usrname}+{audi}+{time}+{numberOfTokens}',
  handler: function (request, h) {
    var timeInMillis = 300
    if(parseInt(request.params.time) > 300) {
      timeInMillis = parseInt(request.params.time)
    }
    var tokens = [];
    for(var i=0; i<parseInt(request.params.numberOfTokens); i++) {
      var token = returnToken(perfPrivateKey, request.params.clientID, request.params.usrname, request.params.audi, timeInMillis)
      tokens.push(token)
    }
    return tokens
  }
});


server.route({
  method: 'GET',
  path: '/getTestToken/{clientID}+{usrname}+{audi}',
  handler: function (request, h) {
    var token = returnToken(testPrivateKey, request.params.clientID, request.params.usrname, request.params.audi)
    return token
  }
});



//Start App
init();