var crypto = require('crypto')
var express = require('express');
var router = express.Router();
var fs = require('fs');
const perfPrivateKey = fs.readFileSync("./perf-privatekey.pem", "ascii");
// const testPrivateKey = fs.readFileSync("./test-privatekey.pem", "ascii");
var StringBuffer = require("stringbuffer");

/* GET home page. */
router.get('/', function(req, res, next) {
  var clientId = req.query.clientId
  var username= req.query.username
  var aud= req.query.aud
  if(req.query.time == null){
    req.query.time = 300
  }
  var time = req.query.time
  var token = returnToken(perfPrivateKey, clientId, username, aud, time)
  res.send({ token: token });
  // res.render('index', { title: token });
});

module.exports = router;

function returnToken(key, clientID, usrname, audi, time){
  var token = new StringBuffer();
  var header = {"alg":"RS256"};
  token.append(Buffer.from(JSON.stringify(header)).toString('base64url'));
  token.append(".");

  var str = {"iss": clientID,
    "sub": usrname,
    "aud": "https://"+audi,
    "exp": parseInt(Date.now()/1000) + time,
    "jti": crypto.randomUUID()};

  token.append(Buffer.from(JSON.stringify(str)).toString('base64url'));


  const sign = crypto.createSign('RSA-SHA256');
  sign.update(Buffer.from(token.toString()));
  const signature = sign.sign(key);
  token.append(".");
  token.append(Buffer.from(signature).toString('base64url'));

  return token.toString()
}